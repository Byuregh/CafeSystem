public class Main {
    public static void main(String[] args) {

        MySystem start = new MySystem();
        start.startProgram();
    }
}