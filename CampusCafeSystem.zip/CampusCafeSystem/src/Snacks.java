public class Snacks extends Item{
        public Snacks(){
            super(ItemCategory.SNACKS);
            foodName = "snacks";
        }

}
