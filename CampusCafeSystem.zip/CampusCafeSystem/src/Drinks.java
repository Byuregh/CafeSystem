public class Drinks extends Item{
    public Drinks() {
        super(ItemCategory.DRINKS);
        itemName = "drink";
    }
}
