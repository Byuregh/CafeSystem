public class Meals extends Item{
    public Meals{
        super(ItemCategory.MEALS);
        itemName = "meal";
    }
}
